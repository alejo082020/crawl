from fastapi import APIRouter
from services.service import obtener_datos

router = APIRouter()

@router.get("/crawler")
async def crawler():
    datos = obtener_datos()
    return datos