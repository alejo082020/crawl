from pydantic import BaseModel

class Guayos(BaseModel):
    nombres: str
    precio: str
    referencia: str
    imagen: str