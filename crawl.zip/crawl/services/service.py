import requests
from models.models import Guayos
from bs4 import BeautifulSoup


def obtener_datos():
    url = "https://www.peopleplays.com/hombre/calzado/guayos?srsltid=AfmBOoqQ7NLOWywcQ4AMmYbXjZsCMUQQ-Xrg5oOw-nV5luCBnxhWfJkP"
    headers = {'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) ''AppleWebKit/537.36 (KHTML, like Gecko) ''Chrome/58.0.3029.110 Safari/537.3')}

    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, "html.parser")

    datos = []

    for producto in soup.find_all("div", class_="vtex-search-result-3-x-galleryItem vtex-search-result-3-x-galleryItem--normal vtex-search-result-3-x-galleryItem--grid pa4"):
        nombre = producto.find("span", class_="vtex-product-summary-2-x-productBrand vtex-product-summary-2-x-productBrand--name--plp vtex-product-summary-2-x-brandName vtex-product-summary-2-x-brandName--name--plp t-body").text.strip()
        precio = producto.find("span", class_="vtex-product-price-1-x-sellingPriceValue vtex-product-price-1-x-sellingPriceValue--selling-price--plp").text.strip()
        referencia = producto.find("span", class_="vtex-product-summary-2-x-description c-muted-2 t-small").text.strip()
        imagen = producto.find("img", class_="vtex-product-summary-2-x-imageNormal vtex-product-summary-2-x-image")["src"]
        
        guayos = Guayos(nombres=nombre, precio=precio, referencia=referencia, imagen=imagen)
        datos.append(guayos)

    return datos